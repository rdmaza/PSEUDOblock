//Fijar Margino
  
    var toolbox = document.getElementById('toolbox');
    var areaBlockly = document.getElementById('blocklyDiv');

    var opciones = {
        toolbox: toolbox,
        collapse: true,
//      comments: false,
//      disable: false,
        maxBlocks: Infinity,
        trashcan: true,
//      horizontalLayout: false,
//      toolboxPosition: 'start',
        tooltips: true,
        css: true,
        media: 'file:../../PSEUDOblock/Arduino/media/',
        rtl: false,
        scrollbars: true,
        sounds: true,
        oneBasedIndex: true
    };

    var workspace = Blockly.inject(areaBlockly, opciones);