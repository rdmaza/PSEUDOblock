//Proceso Margino
  
   window.blockly_loaded = function(blockly){
      return window.Blockly = blockly;
    }  

    function borrarARDU() {
       Blockly.mainWorkspace.clear();
       window.parent.document.getElementById('textoARDU').value = "";
    }
 
    function mostrarARDU() {
      var titulo = '\n  // Programa en Arduino \n';
      var cabecera = '\n  #include <Marduino.h> \n \n';
      var codigo = Blockly.JavaScript.workspaceToCode();
            
      var s = codigo.split("\n");
      var p = s[0].indexOf("var");
      var n = s.length;
      var c, q;
      var band = 0;
	  
	  if (p == 0){ 
         codigo = "";
         for (var i = 1; i < n-2; i++){
            c = s[i+2];
            if ((c != "") || (c != "\n")){
              q = c.indexOf("var");
              if (q != (-1)) codigo += c + "\n";
              else {
                 if (band == 0) {
                    codigo += "\n" + c + "\n";
                    band = 1;
                 } 
                 else codigo += c + "\n";
              }
            }
          }
        }
		
      var programa = titulo.concat(cabecera, codigo);
      window.parent.document.getElementById('textoARDU').value = programa;
   }


// guardar bloques
function guardar() {
  var xml = Blockly.Xml.workspaceToDom(Blockly.mainWorkspace);
  var xml_texto = Blockly.Xml.domToPrettyText(xml);
  window.localStorage.setItem("blockly.txt", xml_texto);
}

// cargar bloques
function cargar() {
  var programa = window.localStorage.getItem("blockly.txt");
  Blockly.mainWorkspace.clear();
  var textToDom = Blockly.Xml.textToDom(programa);
  Blockly.Xml.domToWorkspace(Blockly.mainWorkspace, textToDom);
}

// borrar bloques
function borrar() {
    //window.localStorage.clear();
	window.parent.document.getElementById('textoARDU').value = "";
}
