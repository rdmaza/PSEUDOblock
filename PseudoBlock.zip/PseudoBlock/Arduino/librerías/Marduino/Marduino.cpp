#include "Arduino.h"
#include "Marduino.h"

int Kd = 10;
int Ka = 5;

void inicia(void){
   
   // ACTUADORES
   
   // M1
   pinMode(x1, OUTPUT);
   pinMode(y1, OUTPUT);
   
   // M2
   pinMode(x2, OUTPUT);
   pinMode(y2, OUTPUT);

   // LEDs
   pinMode(LED1, OUTPUT);
   pinMode(LED2, OUTPUT);


   // SENSORES

   // Distancia
  pinMode(Tx1,OUTPUT);
  pinMode(Rx1,INPUT);
  Serial.begin(9600);
  digitalWrite(Tx1,LOW);
  digitalWrite(Rx1,LOW); 

  // Digitales
  pinMode(DG1, INPUT);
  pinMode(DG2, INPUT);
}


// Motores

void motores(int a, int b, int c, int d){
   digitalWrite(x1, a);
   digitalWrite(y1, b);
   digitalWrite(x2, c);
   digitalWrite(y2, d);
} 


void alto(){
   motores(LOW, LOW, LOW, LOW);
}


void avanza(int d){
   int t;

   motores(HIGH, LOW, HIGH, LOW);
   
   t = d * Kd;
   delay(t);

   alto();
}


void retrocede(int d){
   int t;

   motores(LOW, HIGH, LOW, HIGH);
 
   t = d * Kd;
   delay(t);

   alto();
}


void giraderecha(int a){
   int t;

   motores(HIGH, LOW, LOW, HIGH);
   
   t = a * Ka;
   delay(t);
   
   alto();
}


void giraizquierda(int a){
   int t;

   motores(LOW, HIGH, HIGH, LOW);
   
   t = a * Ka;
   delay(t);

   alto();
}


// SENSORES

// Digitales

nt sensorDistancia(int n){
  int valor;
  if (n == 1) {
     digitalWrite(Tx1,HIGH);
     delayMicroseconds(10);
     digitalWrite(Tx1,LOW);
     long t = pulseIn(Rx1,HIGH);
     valor = t/59;
  }
  return(valor);
}

int sensorReflexion(int n){
  int valor;
  if (n == 1) {
     valor = digitalRead(DG1);
  }
  if (n == 2) {
     valor = digitalRead(DG2);
  }
  return(valor);
}

int sensorContacto(int n){
  int valor;
  if (n == 1) {
     valor = digitalRead(DG1);
  }
  if (n == 2) {
     valor = digitalRead(DG2);
  }
  return(valor);
}


// Anal�gicos

int sensorLuz(int n){
  int valor;
  if (n == 1) {
     valor = analogRead(AN1);
  }
  if (n == 2) {
     valor = analogRead(AN2);
  }
  return(valor);
}


int sensorSonido(int n){
  int valor;
  if (n == 1) {
     valor = analogRead(AN1);
  }
  if (n == 2) {
     valor = analogRead(AN2);
  }
  return(valor);
}


//LEDs

void prendeLED(int n){
    if (n == 1){
       digitalWrite(LED1, HIGH);
    }
    if (n == 2){
       digitalWrite(LED2, HIGH);
    }
}

void apagaLED(int n){
    if (n == 1){
       digitalWrite(LED1, LOW);
    }
    if (n == 2){
       digitalWrite(LED2, LOW);
    }
}
  
void esperaSeg(int d){
   int t; 
   t = 1000 * d;
   delay(t);
}

void esperaMiliseg(int d){
   delay(d);
}

