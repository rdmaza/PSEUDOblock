#include "Arduino.h"

#ifndef Marduino_H
#define Marduino_H


// MOTORES

// Motor 1 - CON2  
#define x1 6     
#define y1 8    

// Motor 2 - CON1
#define x2 11
#define y2 12



// SENSORES

// Digitales
#define Tx1 2 // Trigger1
#define Rx1 3 // Echo1

// Anal�gicos
#define AN1 A2 // CON6
#define AN2 A0 // CON5


// LEDs
#define LED1 3 // CON6
#define LED2 9 // CON5


// Setup
void inicia(void);


// Motores
void alto(void);
void avanza(int d);
void retrocede(int d);
void giraderecha(int a);
void giraizquierda(int a);


// Sensores Digitales
int sensorReflexion(int n);
int sensorContacto(int n);


// Sensores Anal�gicos
int sensorDistancia(int n);
int sensorLuz(int n);
int sensorSonido(int n);


// LEDs
void prendeLED(int n);
void apagaLED(int n);
void esperaSeg(int n);
void esperaMiliseg(int n);


#endif